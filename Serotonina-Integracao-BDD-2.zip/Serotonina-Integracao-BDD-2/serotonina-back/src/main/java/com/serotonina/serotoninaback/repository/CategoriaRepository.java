package com.serotonina.serotoninaback.repository;

import org.springframework.data.repository.CrudRepository;

import com.serotonina.serotoninaback.model.Categoria;

public interface CategoriaRepository extends CrudRepository<Categoria, Long>{
    
}
