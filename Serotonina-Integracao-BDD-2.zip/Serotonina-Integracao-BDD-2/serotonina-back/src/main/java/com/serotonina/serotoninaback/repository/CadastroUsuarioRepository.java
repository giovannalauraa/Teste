package com.serotonina.serotoninaback.repository;

import org.springframework.data.repository.CrudRepository;

import com.serotonina.serotoninaback.model.CadastroUsuario;

public interface CadastroUsuarioRepository extends CrudRepository<CadastroUsuario, Long>{
    
}
