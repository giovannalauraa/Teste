package com.serotonina.serotoninaback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerotoninaBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
